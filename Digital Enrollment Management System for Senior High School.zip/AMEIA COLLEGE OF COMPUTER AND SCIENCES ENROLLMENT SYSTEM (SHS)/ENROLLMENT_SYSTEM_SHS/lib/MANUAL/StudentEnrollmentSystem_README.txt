STUDENT ENROLLMENT SYSTEM — UPDATED DOCUMENTATION
Group 16: Castor, Tejero, Mesa

FILES
1. StudentEnrollmentSystem_Testing_Guide_Updated.txt
   Sample database IDs, student application walkthrough, test cases, and troubleshooting.

2. StudentEnrollmentSystem_User_Manual.txt
   Setup, running the program, registration, login, enrollment, and common problems.

3. StudentEnrollmentSystem_Code_Explanation.txt
   Explanation of the available Java source plus the complete source code appended at the end.

4. StudentEnrollmentSystem_Source_Code.txt
   Standalone copy of the available StudentEnrollmentSystem.java source code as plain text.

